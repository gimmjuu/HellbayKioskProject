﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace HellbayKioskProject {
    public partial class ManageForm : Form {
        public ManageForm() {
            InitializeComponent();
        }

        private void ManageForm_Load(object sender, EventArgs e) {
            // combobox add value

            for (int i = 0; i < 12; i++) {
                cbBoxDate.Items.Add($"2023년 {i + 1}월");
            }
            cbBoxDate.SelectedIndex = 0;

            // Rounded Controll
            tbDetail.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, tbDetail.Width, tbDetail.Height, 15, 15));
            flowOrderList.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, flowOrderList.Width, flowOrderList.Height + 20, 15, 15));
        }

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

    }
}
